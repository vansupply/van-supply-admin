// v5: disable the old empty service worker so it cannot add request overhead.
self.addEventListener('install', () => self.skipWaiting())
self.addEventListener('activate', event => {
  event.waitUntil(self.registration.unregister().then(() => self.clients.claim()))
})
