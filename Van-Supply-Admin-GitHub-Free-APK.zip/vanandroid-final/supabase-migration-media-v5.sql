-- VAN SUPPLY v5 MEDIA FIX
-- Jalankan SEKALI di Supabase SQL Editor pada project yang sudah berjalan.
-- Aman dijalankan berulang kali.

alter table public.categories
  add column if not exists image_url text default '/logo.svg';

alter table public.products
  add column if not exists image_url text default '/logo.svg';

alter table public.banners
  add column if not exists image_url text default '';

alter table public.banners
  add column if not exists sort_order integer not null default 0;

alter table public.banners
  add column if not exists active boolean not null default true;

alter table public.products
  add column if not exists show_homepage boolean not null default true;

update public.categories
set image_url = '/logo.svg'
where image_url is null or image_url = '';

update public.products
set image_url = '/logo.svg'
where image_url is null or image_url = '';

update public.banners
set sort_order = 0
where sort_order is null;

-- Urutan banner selalu numerik dan dimulai dari 0.
-- Tidak perlu mengubah judul/subjudul lama; v5 hanya tidak menampilkannya.

create index if not exists idx_products_category_active
  on public.products(category_id, active);

create index if not exists idx_products_home_active
  on public.products(show_homepage, active);

create index if not exists idx_banners_active_order
  on public.banners(active, sort_order);
