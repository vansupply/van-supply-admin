-- Jalankan SEKALI di Supabase SQL Editor.
-- Menambahkan kontrol apakah produk boleh tampil di halaman depan.
alter table public.products add column if not exists show_homepage boolean not null default true;
update public.products set show_homepage = true where show_homepage is null;
