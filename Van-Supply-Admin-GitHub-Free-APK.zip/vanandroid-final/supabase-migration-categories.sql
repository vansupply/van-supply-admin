-- Jalankan SEKALI di Supabase SQL Editor pada project Van Supply yang sudah ada.
-- Menambahkan gambar/logo untuk setiap kategori.
alter table public.categories add column if not exists image_url text default '/logo.svg';
update public.categories set image_url = '/logo.svg' where image_url is null or image_url = '';
