# Van Supply — notify-admin-order

Sends a Firebase Cloud Messaging push notification to the Android Admin app when an `orders` INSERT webhook arrives.

## Secrets in Supabase
Set these Edge Function secrets (never put them in the APK/frontend):

- `FIREBASE_PROJECT_ID`
- `FIREBASE_CLIENT_EMAIL`
- `FIREBASE_PRIVATE_KEY`
- `ORDER_WEBHOOK_SECRET` (recommended)

Use the Firebase service-account JSON to obtain the first three values. Keep the private key exactly secret; when pasted into Supabase, escaped `\\n` is accepted and normalized by the function.

## Deploy
From the project root:

```bash
supabase functions deploy notify-admin-order --no-verify-jwt
```

Or create/deploy the function from the Supabase Dashboard.

## Database Webhook
In Supabase Dashboard → Database → Webhooks, create an `INSERT` webhook for:

- Schema: `public`
- Table: `orders`
- Event: `INSERT`
- Target: Edge Function
- Function: `notify-admin-order`
- Method: `POST`
- Header: `x-webhook-secret: <same ORDER_WEBHOOK_SECRET>`
- Content-Type: `application/json`

The Android app subscribes to the `van-supply-admin` FCM topic.
