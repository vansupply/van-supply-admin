const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-webhook-secret',
  'Content-Type': 'application/json',
}

function base64url(input: Uint8Array | string) {
  const bytes = typeof input === 'string' ? new TextEncoder().encode(input) : input
  let binary = ''
  for (const b of bytes) binary += String.fromCharCode(b)
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
}

function pemToDer(pem: string) {
  const b64 = pem.replace(/-----BEGIN PRIVATE KEY-----/g, '').replace(/-----END PRIVATE KEY-----/g, '').replace(/\s/g, '')
  const raw = atob(b64)
  const out = new Uint8Array(raw.length)
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i)
  return out
}

async function createAccessToken(clientEmail: string, privateKeyPem: string) {
  const now = Math.floor(Date.now() / 1000)
  const header = base64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }))
  const claim = base64url(JSON.stringify({
    iss: clientEmail,
    scope: 'https://www.googleapis.com/auth/firebase.messaging',
    aud: 'https://oauth2.googleapis.com/token',
    iat: now,
    exp: now + 3600,
  }))
  const unsigned = `${header}.${claim}`
  const key = await crypto.subtle.importKey(
    'pkcs8',
    pemToDer(privateKeyPem),
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign'],
  )
  const signature = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, new TextEncoder().encode(unsigned))
  const assertion = `${unsigned}.${base64url(new Uint8Array(signature))}`

  const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      assertion,
    }),
  })
  const tokenJson = await tokenRes.json()
  if (!tokenRes.ok || !tokenJson.access_token) throw new Error(`Google OAuth failed: ${JSON.stringify(tokenJson)}`)
  return tokenJson.access_token as string
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })

  try {
    const expectedSecret = Deno.env.get('ORDER_WEBHOOK_SECRET')
    if (expectedSecret) {
      const received = req.headers.get('x-webhook-secret')
      if (received !== expectedSecret) return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401, headers: cors })
    }

    const payload = await req.json()
    if (payload?.type && payload.type !== 'INSERT') {
      return new Response(JSON.stringify({ ok: true, ignored: true }), { status: 200, headers: cors })
    }

    const order = payload?.record ?? payload
    if (!order?.id && !order?.order_no) throw new Error('Missing order record')

    const projectId = Deno.env.get('FIREBASE_PROJECT_ID')
    const clientEmail = Deno.env.get('FIREBASE_CLIENT_EMAIL')
    const privateKey = Deno.env.get('FIREBASE_PRIVATE_KEY')?.replace(/\\n/g, '\n')
    if (!projectId || !clientEmail || !privateKey) throw new Error('Firebase secrets are not configured')

    const accessToken = await createAccessToken(clientEmail, privateKey)
    const orderNo = order.order_no || order.id
    const total = Number(order.total || 0).toLocaleString('id-ID')
    const title = 'Pesanan Baru!'
    const body = `${orderNo} • Rp${total}`

    const response = await fetch(`https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message: {
          topic: 'van-supply-admin',
          notification: { title, body },
          data: {
            type: 'new_order',
            order_id: String(order.id || ''),
            order_no: String(orderNo),
          },
          android: {
            priority: 'high',
            notification: {
              channel_id: 'orders',
              sound: 'default',
            },
          },
        },
      }),
    })

    const result = await response.json()
    if (!response.ok) throw new Error(`FCM failed: ${JSON.stringify(result)}`)

    return new Response(JSON.stringify({ ok: true, messageId: result.name }), { status: 200, headers: cors })
  } catch (error) {
    console.error(error)
    return new Response(JSON.stringify({ ok: false, error: String(error?.message || error) }), { status: 500, headers: cors })
  }
})
