# Van Supply Admin Android

Native Android shell for the existing Van Supply admin panel, with Firebase Cloud Messaging (FCM) for order alerts.

## Before building

1. Open this `android/` folder in Android Studio.
2. Put your Firebase Android config at:
   `android/app/google-services.json`
3. In `android/app/build.gradle`, replace `ADMIN_URL` with the real Netlify admin URL, for example:
   `https://your-site.netlify.app/panel-x9-admin`
4. Sync Gradle and build a debug APK.

## FCM
The app subscribes to the topic `van-supply-admin`.
The Supabase Edge Function `notify-admin-order` sends new-order notifications to that topic.

Android 13+ requires notification permission; the app requests it on first launch.

## Important
Never put Firebase service-account credentials or a Supabase service-role key in this Android project. Only `google-services.json` belongs in the Android app. The service-account private key stays in Supabase Edge Function secrets.

## Direct order detail notification
Notification taps now carry `order_id` and `order_no` into the admin URL. The admin web panel reads these parameters and opens the matching order detail automatically.
