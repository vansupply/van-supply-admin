package com.vansupply.admin

import android.app.PendingIntent
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class VanSupplyMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: message.data["title"] ?: "Pesanan Baru!"
        val body = message.notification?.body ?: message.data["body"] ?: "Ada pesanan baru di Van Supply."
        val orderId = message.data["order_id"]
        val orderNo = message.data["order_no"]

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (!orderId.isNullOrBlank()) putExtra("order_id", orderId)
            if (!orderNo.isNullOrBlank()) putExtra("order_no", orderNo)
        }

        val requestCode = (orderId ?: System.currentTimeMillis().toString()).hashCode()
        val pending = PendingIntent.getActivity(
            this,
            requestCode,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val n = NotificationCompat.Builder(this, "orders")
            .setSmallIcon(com.vansupply.admin.R.drawable.ic_van_supply)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()

        NotificationManagerCompat.from(this).notify(requestCode, n)
    }
}
