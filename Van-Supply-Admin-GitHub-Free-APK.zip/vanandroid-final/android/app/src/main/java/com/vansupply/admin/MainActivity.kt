package com.vansupply.admin

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        requestNotificationPermission()
        FirebaseMessaging.getInstance().subscribeToTopic("van-supply-admin")

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    openOrderFromNotification(intent)
                }
            }
            webChromeClient = WebChromeClient()
            setBackgroundColor(0xFF09060F.toInt())
        }
        setContentView(web)
        loadAdmin(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        orderScriptStarted = false
        loadAdmin(intent)
    }

    private fun loadAdmin(intent: Intent?) {
        val orderId = intent?.getStringExtra("order_id")
            ?: intent?.data?.getQueryParameter("order_id")
        val orderNo = intent?.getStringExtra("order_no")
            ?: intent?.data?.getQueryParameter("order_no")
        pendingOrderId = orderId
        pendingOrderNo = orderNo
        web.loadUrl(BuildConfig.ADMIN_URL)
    }

    private var pendingOrderId: String? = null
    private var pendingOrderNo: String? = null
    private var orderScriptStarted = false

    private fun openOrderFromNotification(sourceIntent: Intent?) {
        val orderNo = pendingOrderNo ?: sourceIntent?.getStringExtra("order_no") ?: return
        if (orderScriptStarted) return
        orderScriptStarted = true
        val safeOrderNo = org.json.JSONObject.quote(orderNo)
        val js = """
            (function() {
              const wanted = $safeOrderNo;
              let tries = 0;
              const timer = setInterval(function() {
                tries++;
                try {
                  const buttons = Array.from(document.querySelectorAll('button'));
                  const pesanan = buttons.find(b => (b.innerText || '').trim() === 'Pesanan');
                  if (pesanan) pesanan.click();
                  const cards = Array.from(document.querySelectorAll('.order-card'));
                  const card = cards.find(c => (c.innerText || '').indexOf(wanted) !== -1);
                  if (card) {
                    clearInterval(timer);
                    card.scrollIntoView({behavior:'smooth', block:'center'});
                    const old = document.getElementById('van-order-detail-overlay');
                    if (old) old.remove();
                    const text = (card.innerText || '').trim();
                    const overlay = document.createElement('div');
                    overlay.id = 'van-order-detail-overlay';
                    overlay.innerHTML = `
                      <div style="position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:999999;padding:18px;display:flex;align-items:center;justify-content:center">
                        <div style="width:min(520px,100%);max-height:88vh;overflow:auto;background:#100b18;color:#fff;border:1px solid rgba(184,120,255,.35);border-radius:20px;padding:20px;box-shadow:0 20px 70px rgba(0,0,0,.55);font-family:system-ui,sans-serif">
                          <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px">
                            <div><div style="font-size:12px;letter-spacing:2px;color:#cba7ff;font-weight:700">DETAIL PESANAN</div><div style="font-size:24px;font-weight:800;margin-top:5px">${wanted}</div></div>
                            <button id="van-order-close" style="border:0;border-radius:12px;padding:10px 14px;background:#292230;color:#fff;font-weight:700">Tutup</button>
                          </div>
                          <div style="white-space:pre-wrap;line-height:1.7;color:#ddd;background:#17101f;border-radius:14px;padding:15px">${text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</div>
                          <div style="margin-top:12px;color:#a99daf;font-size:12px">Buka dari notifikasi Van Supply Admin.</div>
                        </div>
                      </div>`;
                    document.body.appendChild(overlay);
                    document.getElementById('van-order-close').onclick=()=>overlay.remove();
                  }
                } catch(e) {}
                if (tries > 30) clearInterval(timer);
              }, 350);
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(
                "orders",
                "Pesanan Van Supply",
                NotificationManager.IMPORTANCE_HIGH
            )
            c.description = "Notifikasi pesanan baru Van Supply"
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                1001
            )
        }
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
