# Van Supply — Gaming Store Purple Neon

Website store responsif + panel admin tersembunyi, dibuat untuk deploy di Netlify dan memakai Supabase sebagai database/auth/storage. Checkout diarahkan ke WhatsApp.

## 1. Jalankan lokal
```bash
npm install
npm run dev
```

## 2. Supabase
1. Buat project Supabase.
2. Buka SQL Editor lalu jalankan seluruh isi `supabase.sql`.
3. Di Authentication → Users, buat user email/password untuk admin.
4. Ambil UUID user tersebut lalu jalankan:
```sql
insert into public.admins(user_id) values ('UUID_USER_ADMIN');
```
5. Project Settings → API: ambil Project URL dan anon public key.
6. Copy `.env.example` menjadi `.env`:
```env
VITE_SUPABASE_URL=https://xxxxx.supabase.co
VITE_SUPABASE_ANON_KEY=ey...
```

## 3. Update database untuk gambar kategori
Jika project Supabase sudah pernah dibuat memakai versi sebelumnya, jalankan file `supabase-migration-categories.sql` **sekali saja** di Supabase SQL Editor. File ini menambahkan kolom gambar/logo kategori tanpa menghapus data yang sudah ada.

Versi baru memungkinkan admin mengubah nama kategori dan upload gambar/logo kategori dari menu **Kategori**.

## 4. Netlify
- Upload repository/folder project ke GitHub lalu connect ke Netlify, atau drag & drop ZIP hasil build/project.
- Build command: `npm run build`
- Publish directory: `dist`
- Tambahkan environment variables yang sama dengan `.env` di Netlify.
- `netlify.toml` sudah mengatur SPA redirect.

## 5. Admin
Panel sengaja tidak ditampilkan pada menu customer. URL:
`/panel-x9-admin`

Admin bisa:
- melihat dashboard + jam/hari/tanggal real-time
- CRUD produk
- upload gambar produk ke Supabase Storage
- import banyak produk via CSV
- hapus semua produk
- naik harga 5%
- bulatkan harga ke atas ke kelipatan Rp500
- CRUD kategori + upload/edit gambar atau logo kategori
- CRUD 3+ banner + upload gambar
- ubah nama store, tagline, WhatsApp, logo
- melihat dan mengubah status pesanan
- menerima realtime order saat panel admin terbuka
- meminta izin browser notification untuk order baru

## 6. Format CSV
Header minimal:
`name,category,price,stock,image_url,description,badge,active`

Contoh:
```csv
name,category,price,stock,image_url,description,badge,active
Mobile Legends 86 Diamonds,Game,20000,9999,https://contoh.com/ml.jpg,86 diamond,POPULER,true
Free Fire 70 Diamonds,Game,10000,9999,https://contoh.com/ff.jpg,70 diamond,HOT,true
```

## Catatan keamanan
- Jangan pernah memasukkan `service_role` key ke frontend/Netlify.
- Frontend hanya memakai anon key + RLS.
- Customer hanya boleh INSERT order; data order tidak dapat dibaca oleh customer melalui API.
- Untuk notifikasi ketika browser/admin benar-benar tertutup, perlu Web Push/FCM atau aplikasi native dengan service push. Versi ini sudah realtime + browser notification saat panel admin aktif.

## Update terbaru (v2)
- Homepage lebih ringkas dan responsive.
- Kategori memiliki gambar/logo dan dapat diedit/upload dari Admin.
- Klik kategori membuka halaman khusus kategori.
- Admin dapat memilih produk mana yang tampil di homepage melalui `Tampilkan di beranda`.
- Tombol/logo store kembali ke Beranda.
- Tombol Back HP dari halaman internal pelanggan diarahkan ke Beranda.
- Admin panel dibuat responsive/mobile tanpa harus memaksa mode desktop.

### Migrasi Supabase untuk kontrol homepage
Pada project Supabase yang sudah ada, jalankan sekali file `supabase-migration-homepage.sql` di SQL Editor.

## v5 Media & Performance Fix

Sebelum deploy v5, jalankan `supabase-migration-media-v5.sql` **sekali** di Supabase SQL Editor. Migration ini memastikan kolom gambar kategori/produk/banner tersedia pada database lama.

Perubahan v5:
- Kategori: hanya upload gambar, URL gambar dihapus dari form.
- Produk: hanya upload gambar, URL gambar dihapus dari form.
- Banner: hanya upload gambar + urutan + aktif; judul, subjudul, dan URL gambar dihapus dari form.
- Banner di storefront sekarang tampil **gambar saja**, tanpa teks overlay.
- Urutan banner mulai dari `0`, `1`, `2`, dst. Leading zero seperti `01` otomatis dibuang.
- Upload gambar dikompres ke WebP di browser sebelum dikirim ke Supabase Storage.
- Upload diberi cache 1 tahun agar gambar yang sama tidak perlu diambil ulang terus-menerus.
- Gambar katalog memakai lazy loading/async decoding.
- Service worker kosong yang sebelumnya tidak memberi cache nyata tidak lagi didaftarkan.

## Free APK build with GitHub Actions

This project includes `.github/workflows/build-apk.yml`.
Create a GitHub repository, upload the project contents, and push to `main`. GitHub Actions will build the debug APK automatically. The APK is available under the workflow run's Artifacts as `van-supply-admin-apk`.

No Google Play Developer account is required for direct APK installation.
