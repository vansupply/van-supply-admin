-- VAN SUPPLY / SUPABASE SETUP
-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.store_settings (
  id bigint primary key default 1 check (id = 1),
  store_name text not null default 'Van Supply',
  tagline text not null default 'Gaming Store • Purple Neon • Cepat & Aman',
  whatsapp text not null default '6281234567890',
  logo_url text not null default '/logo.svg',
  primary_color text not null default '#8b5cf6',
  currency text not null default 'IDR',
  updated_at timestamptz not null default now()
);
insert into public.store_settings(id) values(1) on conflict(id) do nothing;

create table if not exists public.categories (
  id text primary key,
  name text not null unique,
  image_url text default '/logo.svg',
  created_at timestamptz not null default now()
);
insert into public.categories(id,name,image_url) values
('cat-games','Game','/logo.svg'),('cat-voucher','Voucher','/logo.svg'),('cat-items','Item & Bundle','/logo.svg')
on conflict(id) do nothing;

create table if not exists public.products (
  id text primary key,
  slug text,
  name text not null,
  category_id text references public.categories(id) on delete set null,
  price bigint not null default 0,
  stock integer not null default 9999,
  image_url text default '/logo.svg',
  description text default '',
  badge text default '',
  active boolean not null default true,
  show_homepage boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into public.products(id,slug,name,category_id,price,stock,image_url,description,badge,active,show_homepage) values
('p-mlbb','mobile-legends-diamonds','Mobile Legends Diamonds','cat-games',15000,9999,'/logo.svg','Top up Mobile Legends cepat. Masukkan ID dan server saat checkout.','TERLARIS',true,true),
('p-ff','free-fire-diamonds','Free Fire Diamonds','cat-games',12000,9999,'/logo.svg','Diamond Free Fire dengan proses otomatis/cepat.','POPULER',true,true),
('p-roblox','roblox-robux','Roblox Robux','cat-voucher',25000,9999,'/logo.svg','Voucher/Robux Roblox. Detail dikonfirmasi via WhatsApp.','',true,true),
('p-valorant','valorant-points','Valorant Points','cat-voucher',35000,9999,'/logo.svg','Top up Valorant Points dengan nominal pilihan.','',true,true),
('p-weekly','weekly-pass','Weekly Pass','cat-items',30000,9999,'/logo.svg','Weekly pass / bundle sesuai game yang tersedia.','HOT',true,true),
('p-monthly','monthly-bundle','Monthly Bundle','cat-items',70000,9999,'/logo.svg','Bundle bulanan untuk gamer yang ingin hemat.','',true,true)
on conflict(id) do nothing;

create table if not exists public.banners (
  id text primary key,
  title text not null default '',
  subtitle text default '',
  image_url text default '',
  sort_order integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
insert into public.banners(id,title,subtitle,sort_order) values
('b1','POWER UP YOUR GAME','Top up cepat • aman • 24/7',0),
('b2','PURPLE NEON SALE','Harga gaming tanpa ribet',1),
('b3','CHECKOUT VIA WHATSAPP','Pesanan diproses admin dengan cepat',2)
on conflict(id) do nothing;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_no text unique,
  customer_name text not null,
  customer_phone text,
  items jsonb not null default '[]'::jsonb,
  total bigint not null default 0,
  note text default '',
  status text not null default 'pending' check (status in ('pending','processing','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.store_settings enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.banners enable row level security;
alter table public.orders enable row level security;
alter table public.admins enable row level security;

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.admins where user_id = auth.uid());
$$;

-- Public catalog/settings reads.
drop policy if exists "public read settings" on public.store_settings;
create policy "public read settings" on public.store_settings for select using (true);
drop policy if exists "public read categories" on public.categories;
create policy "public read categories" on public.categories for select using (true);
drop policy if exists "public read products" on public.products;
create policy "public read products" on public.products for select using (active = true or public.is_admin());
drop policy if exists "public read banners" on public.banners;
create policy "public read banners" on public.banners for select using (active = true or public.is_admin());

-- Admin management.
drop policy if exists "admin settings" on public.store_settings;
create policy "admin settings" on public.store_settings for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin categories" on public.categories;
create policy "admin categories" on public.categories for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin products" on public.products;
create policy "admin products" on public.products for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin banners" on public.banners;
create policy "admin banners" on public.banners for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin orders read" on public.orders;
create policy "admin orders read" on public.orders for select using (public.is_admin());
drop policy if exists "admin orders update" on public.orders;
create policy "admin orders update" on public.orders for update using (public.is_admin()) with check (public.is_admin());
-- Checkout needs public INSERT only. Customers cannot read/update orders.
drop policy if exists "public create order" on public.orders;
create policy "public create order" on public.orders for insert with check (status = 'pending');
drop policy if exists "admin admins" on public.admins;
create policy "admin admins" on public.admins for all using (public.is_admin()) with check (public.is_admin());

-- Storage bucket for logos/products/banners.
insert into storage.buckets (id,name,public) values ('store-assets','store-assets',true) on conflict(id) do update set public=true;
drop policy if exists "public view store assets" on storage.objects;
create policy "public view store assets" on storage.objects for select using (bucket_id='store-assets');
drop policy if exists "admin upload store assets" on storage.objects;
create policy "admin upload store assets" on storage.objects for insert with check (bucket_id='store-assets' and public.is_admin());
drop policy if exists "admin update store assets" on storage.objects;
create policy "admin update store assets" on storage.objects for update using (bucket_id='store-assets' and public.is_admin());
drop policy if exists "admin delete store assets" on storage.objects;
create policy "admin delete store assets" on storage.objects for delete using (bucket_id='store-assets' and public.is_admin());

-- Realtime for new orders.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='orders'
  ) then
    alter publication supabase_realtime add table public.orders;
  end if;
end $$;
